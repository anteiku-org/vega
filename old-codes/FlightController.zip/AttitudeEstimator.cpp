#include "AttitudeEstimator.h"
#include <math.h>


// =====================================================
// Constructor
// =====================================================

AttitudeEstimator::AttitudeEstimator() {
  // Identity quaternion

  qw = 1.0f;
  qx = 0.0f;
  qy = 0.0f;
  qz = 0.0f;


  roll = 0.0f;
  pitch = 0.0f;
  yaw = 0.0f;
  // Mahony-style correction gains

  accelKp = 1.0f;
  accelKi = 0.02f;


  // Integral error

  integralX = 0.0f;
  integralY = 0.0f;
  integralZ = 0.0f;
}


// =====================================================
// Initialize attitude from accelerometer
// =====================================================

void AttitudeEstimator::initialize(const IMUData &data) {
  integralX = 0.0f;
  integralY = 0.0f;
  integralZ = 0.0f;
  roll = calculateAccelRoll(data);
  pitch = calculateAccelPitch(data);
  yaw = 0.0f;

  // Convert Euler → quaternion
  float phi =roll * PI / 180.0f;
  float theta =pitch * PI / 180.0f;
  float psi =yaw * PI / 180.0f;


  float cr = cos(phi * 0.5f);
  float sr = sin(phi * 0.5f);

  float cp = cos(theta * 0.5f);
  float sp = sin(theta * 0.5f);

  float cy = cos(psi * 0.5f);
  float sy = sin(psi * 0.5f);


  qw =
    cr * cp * cy
    + sr * sp * sy;

  qx =
    sr * cp * cy
    - cr * sp * sy;

  qy =
    cr * sp * cy
    + sr * cp * sy;

  qz =
    cr * cp * sy
    - sr * sp * cy;


  normalizeQuaternion();
  updateEulerAngles();
}


// =====================================================
// Quaternion gyro integration
// =====================================================

void AttitudeEstimator::update(
  const IMUData &data,
  float dt) {
  if (dt <= 0.0f || dt > 0.1f)
    return;


  // ------------------------------------------------
  // Convert gyro °/s → rad/s
  // ------------------------------------------------

  float gx =
    data.gx * PI / 180.0f;

  float gy =
    data.gy * PI / 180.0f;

  float gz =
    data.gz * PI / 180.0f;


  // ------------------------------------------------
  // Accelerometer-based quaternion correction
  // ------------------------------------------------

  applyAccelerometerCorrection(
    data,
    dt,
    gx,
    gy,
    gz);


  // ------------------------------------------------
  // Quaternion derivative
  // ------------------------------------------------

  float qDotW =
    0.5f * (-qx * gx - qy * gy - qz * gz);


  float qDotX =
    0.5f * (qw * gx + qy * gz - qz * gy);


  float qDotY =
    0.5f * (qw * gy - qx * gz + qz * gx);


  float qDotZ =
    0.5f * (qw * gz + qx * gy - qy * gx);


  // ------------------------------------------------
  // Integrate quaternion
  // ------------------------------------------------

  qw += qDotW * dt;
  qx += qDotX * dt;
  qy += qDotY * dt;
  qz += qDotZ * dt;


  // ------------------------------------------------
  // Normalize
  // ------------------------------------------------

  normalizeQuaternion();


  // ------------------------------------------------
  // Convert quaternion to Euler angles
  // ------------------------------------------------

  updateEulerAngles();
}


// =====================================================
// Quaternion normalization
// =====================================================

void AttitudeEstimator::normalizeQuaternion() {
  float magnitude =
    sqrt(
      qw * qw
      + qx * qx
      + qy * qy
      + qz * qz);


  if (magnitude <= 0.0f) {
    qw = 1.0f;
    qx = 0.0f;
    qy = 0.0f;
    qz = 0.0f;

    return;
  }


  qw /= magnitude;
  qx /= magnitude;
  qy /= magnitude;
  qz /= magnitude;
}


// =====================================================
// Quaternion → Euler
// =====================================================

void AttitudeEstimator::updateEulerAngles() {
  // -----------------------------------------
  // Roll
  // -----------------------------------------

  float sinRoll =
    2.0f * (qw * qx + qy * qz);


  float cosRoll =
    1.0f
    - 2.0f * (qx * qx + qy * qy);


  roll =
    atan2(
      sinRoll,
      cosRoll)
    * 180.0f / PI;


  // -----------------------------------------
  // Pitch
  // -----------------------------------------

  float sinPitch =
    2.0f * (qw * qy - qz * qx);


  if (sinPitch > 1.0f)
    sinPitch = 1.0f;

  if (sinPitch < -1.0f)
    sinPitch = -1.0f;


  pitch =
    asin(sinPitch)
    * 180.0f / PI;


  // -----------------------------------------
  // Yaw
  // -----------------------------------------

  float sinYaw =
    2.0f * (qw * qz + qx * qy);


  float cosYaw =
    1.0f
    - 2.0f * (qy * qy + qz * qz);


  yaw =
    atan2(
      sinYaw,
      cosYaw)
    * 180.0f / PI;
}


// =====================================================
// Accelerometer Roll
// =====================================================

float AttitudeEstimator::calculateAccelRoll(
  const IMUData &data) {
  return atan2(
           data.ay,
           data.az)
         * 180.0f / PI;
}


// =====================================================
// Accelerometer Pitch
// =====================================================

float AttitudeEstimator::calculateAccelPitch(
  const IMUData &data) {
  return atan2(
           -data.ax,
           sqrt(
             data.ay * data.ay
             + data.az * data.az))
         * 180.0f / PI;
}


// =====================================================
// Getters
// =====================================================

float AttitudeEstimator::getRoll() {
  return roll;
}


float AttitudeEstimator::getPitch() {
  return pitch;
}


float AttitudeEstimator::getYaw() {
  return yaw;
}
/*
  QuaternionNorm function
*/
float AttitudeEstimator::getQuaternionNorm()
{
    return sqrt(
        qw * qw +
        qx * qx +
        qy * qy +
        qz * qz
    );
}
void AttitudeEstimator::applyAccelerometerCorrection(
  const IMUData &data,
  float dt,
  float &gx,
  float &gy,
  float &gz) {
  // ------------------------------------------------
  // Accelerometer magnitude
  // ------------------------------------------------

  float ax = data.ax;
  float ay = data.ay;
  float az = data.az;

  float accelMagnitude =
    sqrt(
      ax * ax + ay * ay + az * az);


  // ------------------------------------------------
  // Ignore accelerometer when magnitude is far
  // from 1 g. This protects the attitude estimate
  // during strong linear acceleration.
  // ------------------------------------------------

  if (accelMagnitude < 0.7f * GRAVITY || accelMagnitude > 1.3f * GRAVITY) {
    return;
  }


  // ------------------------------------------------
  // Normalize accelerometer
  // ------------------------------------------------

  ax /= accelMagnitude;
  ay /= accelMagnitude;
  az /= accelMagnitude;


  // ------------------------------------------------
  // Gravity direction predicted by quaternion
  //
  // At level:
  //
  // vx = 0
  // vy = 0
  // vz = 1
  // ------------------------------------------------

  float vx =
    2.0f * (qx * qz - qw * qy);

  float vy =
    2.0f * (qw * qx + qy * qz);

  float vz =
    qw * qw
    - qx * qx
    - qy * qy
    + qz * qz;


  // ------------------------------------------------
  // Accelerometer × estimated gravity
  //
  // This gives the direction in which the
  // quaternion needs to be corrected.
  // ------------------------------------------------

  float errorX =
    ay * vz - az * vy;

  float errorY =
    az * vx - ax * vz;

  float errorZ =
    ax * vy - ay * vx;


  // ------------------------------------------------
  // No yaw correction from accelerometer
  //
  // Gravity contains no information about yaw.
  // ------------------------------------------------

  errorZ = 0.0f;


  // ------------------------------------------------
  // Integral feedback
  // ------------------------------------------------

  integralX += errorX * accelKi * dt;
  integralY += errorY * accelKi * dt;
  integralZ = 0.0f;


  // Prevent integral windup

  const float integralLimit = 0.5f;

  if (integralX > integralLimit)
    integralX = integralLimit;

  if (integralX < -integralLimit)
    integralX = -integralLimit;


  if (integralY > integralLimit)
    integralY = integralLimit;

  if (integralY < -integralLimit)
    integralY = -integralLimit;


  // ------------------------------------------------
  // Apply proportional + integral correction
  // ------------------------------------------------

  gx +=
    accelKp * errorX + integralX;

  gy +=
    accelKp * errorY + integralY;

  // No accelerometer yaw correction
  gz += 0.0f;
}
