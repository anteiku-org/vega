#ifndef ATTITUDE_ESTIMATOR_H
#define ATTITUDE_ESTIMATOR_H

#include "MPU6500.h"

class AttitudeEstimator {
public:

  AttitudeEstimator();

  void initialize(const IMUData &data);

  void update(
    const IMUData &data,
    float dt);

  float getRoll();
  float getPitch();
  float getYaw();
  float getQuaternionNorm();

private:

  // Quaternion attitude state

  float qw;
  float qx;
  float qy;
  float qz;


  // Euler representation
  // used for output only

  float roll;
  float pitch;
  float yaw;

  float accelKp;
  float accelKi;

  float integralX;
  float integralY;
  float integralZ;

  void applyAccelerometerCorrection(
    const IMUData &data,
    float dt,
    float &gx,
    float &gy,
    float &gz);
  void normalizeQuaternion();

  void updateEulerAngles();

  float calculateAccelRoll(
    const IMUData &data);

  float calculateAccelPitch(
    const IMUData &data);
};

#endif