#include "BMP280.h"
extern TwoWire Wire2;

BMP280Driver::BMP280Driver() {
  temperature = 0.0f;
  pressure = 0.0f;

  altitude = 0.0f;
  altitudeRaw = 0.0f;

  referencePressure = 101325.0f;
  altitudeFilterAlpha = 0.1f;
  altitudeInitialized = false;
}

bool BMP280Driver::begin(uint8_t address) {
//    wire.begin();

 if (!sensor.begin(address)){
    return false;
  }
  sensor.setSampling(
    Adafruit_BMP280::MODE_NORMAL,
    Adafruit_BMP280::SAMPLING_X2,   // Temperature
    Adafruit_BMP280::SAMPLING_X16,  // Pressure
    Adafruit_BMP280::FILTER_X16,    // IIR filter
    Adafruit_BMP280::STANDBY_MS_500);
  return true;
}

bool BMP280Driver::update() {
  temperature = sensor.readTemperature();
  pressure = sensor.readPressure();

  if (referencePressure <= 0.0f)
    return false;
  // -----------------------------------------
  // Pressure → relative altitude
  // -----------------------------------------
  altitudeRaw = 44330.0f * (1.0f - pow(pressure / referencePressure, 0.19029495f));
  // -----------------------------------------
  // Initialize filter
  // -----------------------------------------
  if (!altitudeInitialized) {
    altitude = altitudeRaw;

    altitudeInitialized = true;
  } else {
    altitude = altitudeFilterAlpha * altitudeRaw + (1.0f - altitudeFilterAlpha) * altitude;
  }
  return true;
}

float BMP280Driver::getTemperature() {
  return temperature;
}

float BMP280Driver::getPressure() {
  return pressure;
}
float BMP280Driver::getRawAltitude() {
  return altitudeRaw;
}
float BMP280Driver::getAltitude() {
  return altitude;
}

// reference-pressure calibration
void BMP280Driver::calibrateReferencePressure(
  uint16_t samples) {
  if (samples == 0)
    return;

  Serial.println();
  Serial.println("================================");
  Serial.println(" BMP280 REFERENCE CALIBRATION");
  Serial.println("================================");
  Serial.println("Keep the FC STILL.");
  Serial.println("Allowing sensor to stabilize...");

  delay(3000);

  float sum = 0.0f;
  uint16_t successfulSamples = 0;

  for (uint16_t i = 0; i < samples; i++) {
    float p = sensor.readPressure();

    if (p > 0.0f) {
      sum += p;
      successfulSamples++;
    }

    delay(20);
  }

  if (successfulSamples == 0) {
    Serial.println("ERROR: Reference calibration failed.");
    return;
  }

  referencePressure =
    sum / successfulSamples;

  // Force altitude zero at the launch point
  altitudeRaw = 0.0f;
  altitude = 0.0f;

  altitudeInitialized = true;

  Serial.print("Reference Pressure : ");
  Serial.print(referencePressure, 2);
  Serial.println(" Pa");

  Serial.println("Reference altitude : 0.00 m");
  Serial.println("================================");
}