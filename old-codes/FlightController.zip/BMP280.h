#ifndef BMP280_DRIVER_H
#define BMP280_DRIVER_H

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_BMP280.h>

struct BMPData {
  float temperature;
  float pressure;
  float altitudeRaw;
  float altitude;
};

class BMP280Driver {
public:

  BMP280Driver();

  bool begin(
    TwoWire &wire,
    uint8_t address = 0x76);

  bool update();

  void calibrateReferencePressure(
    uint16_t samples = 100);

  float getTemperature();
  float getPressure();
  float getAltitude();
  float getRawAltitude();
private:

  Adafruit_BMP280 sensor;

  float temperature;
  float pressure;
  float altitude;
  float altitudeRaw;
  float referencePressure;
  float altitudeFilterAlpha;
  bool altitudeInitialized;
};

#endif