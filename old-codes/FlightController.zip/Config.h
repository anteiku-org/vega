#ifndef CONFIG_H
#define CONFIG_H

// =====================================================
// Falcon FC Build Configuration
// =====================================================

// 1 = debugging enabled
// 0 = minimal flight firmware
#define DEBUG_MODE 1

// 1 = include calibration routines
// 0 = completely compile calibration routines out
#define CALIBRATION_MODE 0

#define SERIAL_BAUD 115200


// =====================================================
// Current MPU6500 Calibration
// =====================================================
//
// These are the latest bench calibration values
// obtained during our development/testing.
//
// They are currently stored as compile-time constants.
// Later we will move these into STM32 Flash storage.
// =====================================================

struct FalconIMUCalibration
{
    float gyroBiasX;
    float gyroBiasY;
    float gyroBiasZ;

    float accelBiasX;
    float accelBiasY;
    float accelBiasZ;

    float accelScaleX;
    float accelScaleY;
    float accelScaleZ;
};


// Latest verified calibration values
static const FalconIMUCalibration FALCON_IMU_CALIBRATION =
{
    // Gyroscope bias
    -2.5299f,
    -2.1177f,
    -0.0005f,

    // Accelerometer bias
     0.0230f,
    -0.0911f,
    -0.4325f,

    // Accelerometer scale
    1.011314f,
    1.009759f,
    0.989623f
};

#endif