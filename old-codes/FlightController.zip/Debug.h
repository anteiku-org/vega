#ifndef DEBUG_H
#define DEBUG_H

#include <Arduino.h>
#include "Config.h"

#if DEBUG_MODE

    #define DEBUG_PRINT(x)       Serial.print(x)
    #define DEBUG_PRINTLN(x)     Serial.println(x)
    #define DEBUG_PRINT_HEX(x)   Serial.print(x, HEX)

#else

    #define DEBUG_PRINT(x)
    #define DEBUG_PRINTLN(x)
    #define DEBUG_PRINT_HEX(x)

#endif

#endif