#include "Config.h"
#include "Debug.h"
#include "pins.h"

#include "MPU6500.h"
#include "AttitudeEstimator.h"
#include "BMP280.h"


// =====================================================
// Objects
// =====================================================

MPU6500 imu;
IMUData data;

AttitudeEstimator attitude;

BMP280Driver bmp;


// =====================================================
// Timing
// =====================================================

unsigned long previousTime = 0;


// =====================================================
// SETUP
// =====================================================

void setup() {
  Serial.begin(SERIAL_BAUD);

  delay(500);
  Wire.setSDA(I2C_SDA);
  Wire.setSCL(I2C_SCL);
  Wire.begin();

  Wire2.begin();
  delay(10);
#if DEBUG_MODE
  Serial.println();
  Serial.println("Project Falcon FC");
  Serial.println("--------------------");
#endif


  // =================================================
  // MPU6500
  // =================================================

  if (!imu.begin()) {
#if DEBUG_MODE
    Serial.println("IMU Initialization Failed");
#endif

    while (1)
      ;
  }

#if DEBUG_MODE
  Serial.println("IMU Initialized Successfully");
#endif


  // =================================================
  // BMP280
  // =================================================

  if (!bmp.begin(0x76)) {
#if DEBUG_MODE
    Serial.println("BMP280 Initialization Failed");
#endif

    while (1)
      ;
  }

#if DEBUG_MODE
  Serial.println("BMP280 Initialized Successfully");
#endif


  // =================================================
  // BMP280 reference pressure
  // =================================================

  bmp.calibrateReferencePressure(200);
  Serial.println("BMP calibration finished.");
  Serial.println("Attempting first IMU read...");

  // =================================================
  // Get first IMU sample
  // =================================================

  if (!imu.readRawData(data)) {
#if DEBUG_MODE
    Serial.println("Initial IMU read failed.");
#endif

    while (1)
      ;
  }


  imu.convertRawData(data);

  imu.applyGyroCalibration(data);
  imu.applyAccelCalibration(data);


  // =================================================
  // Initialize attitude estimator
  // =================================================
  Serial.println("Initial IMU read successful.");
  Serial.println("Initializing attitude estimator...");
  attitude.initialize(data);
  Serial.println("Attitude initialization complete.");

#if DEBUG_MODE
  Serial.println("Attitude estimator initialized.");

  Serial.print("Initial Roll : ");
  Serial.println(attitude.getRoll(), 2);

  Serial.print("Initial Pitch : ");
  Serial.println(attitude.getPitch(), 2);

  Serial.print("Initial Yaw : ");
  Serial.println(attitude.getYaw(), 2);

#endif


  // =================================================
  // Initialize timing
  // =================================================

  previousTime = micros();

#if DEBUG_MODE
  Serial.println("Starting main loop...");
#endif
}


// =====================================================
// LOOP
// =====================================================

void loop() {
#if DEBUG_MODE
  Serial.println("LOOP RUNNING");
#endif


  // =================================================
  // Timing
  // =================================================

  unsigned long currentTime = micros();

  float dt =
    (currentTime - previousTime)
    / 1000000.0f;

  previousTime = currentTime;


  // =================================================
  // MPU6500
  // =================================================

  Serial.println("Before readRawData");

  bool imuReadOK = imu.readRawData(data);

  Serial.println("After readRawData");

  if (!imuReadOK) {
    Serial.println("Initial IMU read FAILED.");
    while (1)
      ;
  }
  imu.convertRawData(data);

  imu.applyGyroCalibration(data);
  imu.applyAccelCalibration(data);

  attitude.update(data, dt);
}


// =================================================
// BMP280
// =================================================

if (!bmp.update()) {
#if DEBUG_MODE
  Serial.println("BMP280 update failed!");
#endif
}


// =================================================
// Combined output
// =================================================

#if DEBUG_MODE

Serial.print("Roll : ");
Serial.print(attitude.getRoll(), 2);

Serial.print(" °   Pitch : ");
Serial.print(attitude.getPitch(), 2);

Serial.print(" °   Yaw : ");
Serial.print(attitude.getYaw(), 2);

Serial.print(" °   Alt : ");
Serial.print(bmp.getAltitude(), 2);

Serial.print(" m   Pressure : ");
Serial.print(bmp.getPressure(), 2);

Serial.print(" Pa   BTemp : ");
Serial.print(bmp.getTemperature(), 2);

Serial.println(" °C");

Serial.println("----------------------------");

#endif


delay(100);
}