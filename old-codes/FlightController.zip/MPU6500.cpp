#include "MPU6500.h"
#include "Debug.h"
#include "pins.h"

// =====================================================
// Constructor
// =====================================================

MPU6500::MPU6500()
{
    wire = nullptr;

    // Load current calibration constants
    // from Config.h.

    gyroBiasX = FALCON_IMU_CALIBRATION.gyroBiasX;
    gyroBiasY = FALCON_IMU_CALIBRATION.gyroBiasY;
    gyroBiasZ = FALCON_IMU_CALIBRATION.gyroBiasZ;

    accelBiasX = FALCON_IMU_CALIBRATION.accelBiasX;
    accelBiasY = FALCON_IMU_CALIBRATION.accelBiasY;
    accelBiasZ = FALCON_IMU_CALIBRATION.accelBiasZ;

    accelScaleX = FALCON_IMU_CALIBRATION.accelScaleX;
    accelScaleY = FALCON_IMU_CALIBRATION.accelScaleY;
    accelScaleZ = FALCON_IMU_CALIBRATION.accelScaleZ;
}


// =====================================================
// MPU6500 Initialization
// =====================================================

bool MPU6500::begin(){
    wire = &Wire;
    delay(100);

    uint8_t id = readRegister(WHO_AM_I);

#if DEBUG_MODE

    Serial.print("WHO_AM_I : 0x");
    Serial.println(id, HEX);

#endif

    if (id != 0x70)
    {
#if DEBUG_MODE

        Serial.println("ERROR: Unexpected WHO_AM_I");

#endif

        return false;
    }


    // -----------------------------------------
    // Power management
    // -----------------------------------------

    writeRegister(PWR_MGMT_1, 0x01);

    delay(100);


    // -----------------------------------------
    // Digital Low Pass Filter
    // -----------------------------------------

    writeRegister(CONFIG, DLPF_BW_41HZ);


    // -----------------------------------------
    // Sample rate
    // -----------------------------------------

    writeRegister(SMPLRT_DIV, SAMPLE_RATE_1000HZ);


    // -----------------------------------------
    // Gyroscope ±500 °/s
    // -----------------------------------------

    writeRegister(GYRO_CONFIG, GYRO_FS_500DPS);


    // -----------------------------------------
    // Accelerometer ±4g
    // -----------------------------------------

    writeRegister(ACCEL_CONFIG, ACCEL_FS_4G);


    // -----------------------------------------
    // Accelerometer DLPF
    // -----------------------------------------

    writeRegister(ACCEL_CONFIG2, DLPF_BW_41HZ);

    delay(100);

    return true;
}


// =====================================================
// Write Register
// =====================================================

void MPU6500::writeRegister(uint8_t reg, uint8_t value)
{
    wire->beginTransmission(MPU6500_ADDRESS);

    wire->write(reg);
    wire->write(value);

    uint8_t status = wire->endTransmission();

#if DEBUG_MODE

    if (status != 0)
    {
        Serial.print("I2C write failed. Register = 0x");
        Serial.print(reg, HEX);

        Serial.print(" Status = ");
        Serial.println(status);
    }

#endif
}


// =====================================================
// Read Register
// =====================================================

uint8_t MPU6500::readRegister(uint8_t reg)
{
    wire->beginTransmission(MPU6500_ADDRESS);

    wire->write(reg);

    uint8_t status = wire->endTransmission(false);

    if (status != 0)
    {
#if DEBUG_MODE

        Serial.print("I2C register write failed. Status = ");
        Serial.println(status);

#endif

        return 0xFF;
    }


    uint8_t received =
        wire->requestFrom(
            MPU6500_ADDRESS,
            (uint8_t)1
        );

    if (received != 1)
    {
#if DEBUG_MODE

        Serial.print("I2C read failed. Register = 0x");
        Serial.println(reg, HEX);

#endif

        return 0xFF;
    }

    return wire->read();
}


// =====================================================
// Read 14 bytes of sensor data
// =====================================================

bool MPU6500::readRawData(IMUData &data)
{
    wire->beginTransmission(MPU6500_ADDRESS);

    wire->write(ACCEL_XOUT_H);

    uint8_t status =
        wire->endTransmission(false);

    if (status != 0)
    {
#if DEBUG_MODE
        Serial.print("MPU6500 register select failed: ");
        Serial.println(status);
#endif
        return false;
    }


    uint8_t received =
        wire->requestFrom(
            MPU6500_ADDRESS,
            (uint8_t)14
        );

    if (received != 14)
    {
#if DEBUG_MODE
        Serial.print("MPU6500 data read failed. Bytes: ");
        Serial.println(received);
#endif
        return false;
    }


    data.ax_raw =
        (int16_t)((wire->read() << 8) | wire->read());

    data.ay_raw =
        (int16_t)((wire->read() << 8) | wire->read());

    data.az_raw =
        (int16_t)((wire->read() << 8) | wire->read());


    data.temperature_raw =
        (int16_t)((wire->read() << 8) | wire->read());


    data.gx_raw =
        (int16_t)((wire->read() << 8) | wire->read());

    data.gy_raw =
        (int16_t)((wire->read() << 8) | wire->read());

    data.gz_raw =
        (int16_t)((wire->read() << 8) | wire->read());

    return true;
}


// =====================================================
// Raw → Physical Units
// =====================================================

void MPU6500::convertRawData(IMUData &data)
{
    // Accelerometer

    data.ax =
        ((float)data.ax_raw / ACCEL_SENSITIVITY)
        * GRAVITY;

    data.ay =
        ((float)data.ay_raw / ACCEL_SENSITIVITY)
        * GRAVITY;

    data.az =
        ((float)data.az_raw / ACCEL_SENSITIVITY)
        * GRAVITY;


    // Gyroscope

    data.gx =
        (float)data.gx_raw / GYRO_SENSITIVITY;

    data.gy =
        (float)data.gy_raw / GYRO_SENSITIVITY;

    data.gz =
        (float)data.gz_raw / GYRO_SENSITIVITY;


    // Temperature

    data.temperature =
        getTemperatureCelsius(
            data.temperature_raw
        );
}


// =====================================================
// Temperature Conversion
// =====================================================

float MPU6500::getTemperatureCelsius(int16_t raw)
{
    return ((float)raw / 333.87f) + 21.0f;
}


// =====================================================
// Apply Gyroscope Calibration
// =====================================================

void MPU6500::applyGyroCalibration(IMUData &data)
{
    data.gx -= gyroBiasX;
    data.gy -= gyroBiasY;
    data.gz -= gyroBiasZ;
}


// =====================================================
// Apply Accelerometer Calibration
// =====================================================

void MPU6500::applyAccelCalibration(IMUData &data)
{
    data.ax =
        (data.ax - accelBiasX)
        * accelScaleX;

    data.ay =
        (data.ay - accelBiasY)
        * accelScaleY;

    data.az =
        (data.az - accelBiasZ)
        * accelScaleZ;
}