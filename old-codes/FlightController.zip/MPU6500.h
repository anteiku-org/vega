#ifndef MPU6500_H
#define MPU6500_H

#include <Arduino.h>
#include <Wire.h>
#include "Config.h"

extern TwoWire Wire2;
// =====================================================
// MPU6500 I2C
// =====================================================

#define MPU6500_ADDRESS 0x68


// =====================================================
// Register Map
// =====================================================

// Identification
#define WHO_AM_I        0x75

// Power
#define PWR_MGMT_1      0x6B
#define PWR_MGMT_2      0x6C

// Configuration
#define CONFIG          0x1A
#define SMPLRT_DIV      0x19

// Gyroscope
#define GYRO_CONFIG     0x1B

// Accelerometer
#define ACCEL_CONFIG    0x1C
#define ACCEL_CONFIG2   0x1D

// Temperature
#define TEMP_OUT_H      0x41
#define TEMP_OUT_L      0x42

// Accelerometer data
#define ACCEL_XOUT_H    0x3B
#define ACCEL_XOUT_L    0x3C
#define ACCEL_YOUT_H    0x3D
#define ACCEL_YOUT_L    0x3E
#define ACCEL_ZOUT_H    0x3F
#define ACCEL_ZOUT_L    0x40

// Gyroscope data
#define GYRO_XOUT_H     0x43
#define GYRO_XOUT_L     0x44
#define GYRO_YOUT_H     0x45
#define GYRO_YOUT_L     0x46
#define GYRO_ZOUT_H     0x47
#define GYRO_ZOUT_L     0x48


// =====================================================
// Full Scale Configuration
// =====================================================

#define GYRO_FS_250DPS  0x00
#define GYRO_FS_500DPS  0x08
#define GYRO_FS_1000DPS 0x10
#define GYRO_FS_2000DPS 0x18

#define ACCEL_FS_2G     0x00
#define ACCEL_FS_4G     0x08
#define ACCEL_FS_8G     0x10
#define ACCEL_FS_16G    0x18


// =====================================================
// Digital Low Pass Filter
// =====================================================

#define DLPF_BW_184HZ   0x01
#define DLPF_BW_92HZ    0x02
#define DLPF_BW_41HZ    0x03
#define DLPF_BW_20HZ    0x04
#define DLPF_BW_10HZ    0x05
#define DLPF_BW_5HZ     0x06

#define SAMPLE_RATE_1000HZ 0x00


// =====================================================
// Conversion Constants
// =====================================================

#define ACCEL_SENSITIVITY 8192.0f
#define GYRO_SENSITIVITY  65.5f
#define GRAVITY           9.80665f


// =====================================================
// IMU Data Structure
// =====================================================

struct IMUData
{
    // -----------------------------
    // Raw data
    // -----------------------------

    int16_t ax_raw;
    int16_t ay_raw;
    int16_t az_raw;

    int16_t gx_raw;
    int16_t gy_raw;
    int16_t gz_raw;

    int16_t temperature_raw;


    // -----------------------------
    // Physical data
    // -----------------------------

    float ax;
    float ay;
    float az;

    float gx;
    float gy;
    float gz;

    float temperature;
};


// =====================================================
// MPU6500 Class
// =====================================================

class MPU6500
{
public:

    MPU6500();

    bool begin();

    bool readRawData(IMUData &data);

    void convertRawData(IMUData &data);

    void applyGyroCalibration(IMUData &data);

    void applyAccelCalibration(IMUData &data);

    float getTemperatureCelsius(int16_t raw);

    // -----------------------------------------
    // Calibration functionality is included
    // ONLY in calibration builds.
    // -----------------------------------------

#if CALIBRATION_MODE

    void calibrateGyro(IMUData &data);

    void calibrateAccelerometer6Point();

#endif


private:

    TwoWire *wire;

    uint8_t readRegister(uint8_t reg);

    void writeRegister(uint8_t reg, uint8_t value);


    // -----------------------------------------
    // Calibration parameters
    // -----------------------------------------

    float gyroBiasX;
    float gyroBiasY;
    float gyroBiasZ;

    float accelBiasX;
    float accelBiasY;
    float accelBiasZ;

    float accelScaleX;
    float accelScaleY;
    float accelScaleZ;
};

#endif