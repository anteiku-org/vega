#include "MPU6500.h"

#if CALIBRATION_MODE

#include <Arduino.h>


// =====================================================
// Gyroscope Calibration
// =====================================================

void MPU6500::calibrateGyro(IMUData &data)
{
    const int SAMPLES = 500;

    float sumX = 0.0f;
    float sumY = 0.0f;
    float sumZ = 0.0f;

    int successfulSamples = 0;


    Serial.println();
    Serial.println("================================");
    Serial.println("     GYRO CALIBRATION");
    Serial.println("================================");
    Serial.println("Keep the flight controller STILL.");
    Serial.println("Do not touch it...");
    Serial.println();

    delay(2000);


    for (int i = 0; i < SAMPLES; i++)
    {
        if (readRawData(data))
        {
            convertRawData(data);

            sumX += data.gx;
            sumY += data.gy;
            sumZ += data.gz;

            successfulSamples++;
        }

        delay(5);
    }


    if (successfulSamples == 0)
    {
        Serial.println("ERROR: Gyro calibration failed.");
        return;
    }


    gyroBiasX =
        sumX / successfulSamples;

    gyroBiasY =
        sumY / successfulSamples;

    gyroBiasZ =
        sumZ / successfulSamples;


    Serial.println();
    Serial.println("Calibration complete.");
    Serial.println();

    Serial.print("Gyro Bias X : ");
    Serial.print(gyroBiasX, 4);
    Serial.println(" °/s");

    Serial.print("Gyro Bias Y : ");
    Serial.print(gyroBiasY, 4);
    Serial.println(" °/s");

    Serial.print("Gyro Bias Z : ");
    Serial.print(gyroBiasZ, 4);
    Serial.println(" °/s");

    Serial.println("================================");
}


// =====================================================
// Six-Point Accelerometer Calibration
// =====================================================

void MPU6500::calibrateAccelerometer6Point()
{
    const int SAMPLES = 500;

    float xPositive = 0.0f;
    float xNegative = 0.0f;

    float yPositive = 0.0f;
    float yNegative = 0.0f;

    float zPositive = 0.0f;
    float zNegative = 0.0f;


    IMUData data;


    // -------------------------------------------------
    // Helper
    // -------------------------------------------------

    auto collectSamples =
        [&](const char *message,
            char axis,
            float &average)
    {
        float sum = 0.0f;

        int successfulSamples = 0;


        Serial.println();
        Serial.println("--------------------------------");
        Serial.println(message);
        Serial.println("Keep the board STILL.");
        Serial.println("Starting in 3 seconds...");
        Serial.println("--------------------------------");

        delay(3000);


        for (int i = 0; i < SAMPLES; i++)
        {
            if (readRawData(data))
            {
                convertRawData(data);

                float value = 0.0f;


                if (axis == 'X')
                    value = data.ax;

                else if (axis == 'Y')
                    value = data.ay;

                else if (axis == 'Z')
                    value = data.az;


                sum += value;

                successfulSamples++;
            }

            delay(2);
        }


        if (successfulSamples > 0)
        {
            average =
                sum / successfulSamples;
        }
        else
        {
            average = 0.0f;
        }
    };


    // -------------------------------------------------
    // Six orientations
    // -------------------------------------------------

    collectSamples(
        "POSITION 1/6 : +X UP",
        'X',
        xPositive
    );

    collectSamples(
        "POSITION 2/6 : -X UP",
        'X',
        xNegative
    );

    collectSamples(
        "POSITION 3/6 : +Y UP",
        'Y',
        yPositive
    );

    collectSamples(
        "POSITION 4/6 : -Y UP",
        'Y',
        yNegative
    );

    collectSamples(
        "POSITION 5/6 : +Z UP",
        'Z',
        zPositive
    );

    collectSamples(
        "POSITION 6/6 : -Z UP",
        'Z',
        zNegative
    );


    // -------------------------------------------------
    // Bias
    // -------------------------------------------------

    accelBiasX =
        (xPositive + xNegative) / 2.0f;

    accelBiasY =
        (yPositive + yNegative) / 2.0f;

    accelBiasZ =
        (zPositive + zNegative) / 2.0f;


    // -------------------------------------------------
    // Scale
    // -------------------------------------------------

    float xSpan =
        (xPositive - xNegative) / 2.0f;

    float ySpan =
        (yPositive - yNegative) / 2.0f;

    float zSpan =
        (zPositive - zNegative) / 2.0f;


    // Protect against division by zero

    if (fabs(xSpan) < 0.001f ||
        fabs(ySpan) < 0.001f ||
        fabs(zSpan) < 0.001f)
    {
        Serial.println();
        Serial.println("ERROR: Invalid calibration span.");
        return;
    }


    accelScaleX =
        GRAVITY / xSpan;

    accelScaleY =
        GRAVITY / ySpan;

    accelScaleZ =
        GRAVITY / zSpan;


    // -------------------------------------------------
    // Print
    // -------------------------------------------------

    Serial.println();
    Serial.println("================================");
    Serial.println("  6-POINT CALIBRATION COMPLETE");
    Serial.println("================================");

    Serial.println();

    Serial.print("+X average : ");
    Serial.println(xPositive, 4);

    Serial.print("-X average : ");
    Serial.println(xNegative, 4);

    Serial.print("+Y average : ");
    Serial.println(yPositive, 4);

    Serial.print("-Y average : ");
    Serial.println(yNegative, 4);

    Serial.print("+Z average : ");
    Serial.println(zPositive, 4);

    Serial.print("-Z average : ");
    Serial.println(zNegative, 4);


    Serial.println();

    Serial.print("Accel Bias X : ");
    Serial.println(accelBiasX, 4);

    Serial.print("Accel Bias Y : ");
    Serial.println(accelBiasY, 4);

    Serial.print("Accel Bias Z : ");
    Serial.println(accelBiasZ, 4);


    Serial.println();

    Serial.print("Accel Scale X : ");
    Serial.println(accelScaleX, 6);

    Serial.print("Accel Scale Y : ");
    Serial.println(accelScaleY, 6);

    Serial.print("Accel Scale Z : ");
    Serial.println(accelScaleZ, 6);

    Serial.println("================================");
}

#endif