#include "pins.h"
#include "MPU6500.h"
#include "AttitudeEstimator.h"

MPU6500 imu;
IMUData data;
AttitudeEstimator attitude;

unsigned long previousTime = 0;
/*
void setup() {
  Serial.begin(115200);

  delay(1000);
  Serial.println("Project Falcon FC");
  //Serial.println("--------------------");

  if (!imu.begin()) {
    Serial.println("IMU Initialization Failed");

    while (1)
      ;
  }

  // Serial.println("IMU Initialized Successfully");

  //imu.printConfiguration();

  // ----------------------------------------
  // Gyroscope calibration
  // ----------------------------------------

  //imu.calibrateGyro(data);

  // ----------------------------------------
  // Six-point accelerometer calibration
  // ----------------------------------------

  //imu.calibrateAccelerometer6Point();

  // ----------------------------------------
  // Get a fresh sensor reading
  // ----------------------------------------

  if (imu.readRawData(data)) {
    imu.convertRawData(data);

    imu.applyGyroCalibration(data);
    imu.applyAccelCalibration(data);

    // ----------------------------------------
    // Initialize attitude from calibrated
    // accelerometer orientation
    // ----------------------------------------
    delay(3000);
    attitude.initialize(data);

    Serial.println("Attitude estimator initialized.");

    Serial.print("Initial Roll : ");
    Serial.println(attitude.getRoll(), 2);

    Serial.print("Initial Pitch : ");
    Serial.println(attitude.getPitch(), 2);
  } else {
    Serial.println("ERROR: Failed to read IMU for attitude initialization.");

    while (1)
      ;
  }

  previousTime = micros();
}


void loop() {
  if (imu.readRawData(data)) {
    unsigned long currentTime = micros();

    float dt =
      (currentTime - previousTime) / 1000000.0f;

    previousTime = currentTime;

    imu.convertRawData(data);

    imu.applyGyroCalibration(data);
    imu.applyAccelCalibration(data);

    attitude.update(data, dt);

    Serial.print("Roll : ");
    Serial.print(attitude.getRoll(), 2);

    Serial.print(" °   Pitch : ");
    Serial.print(attitude.getPitch(), 2);

    Serial.println(" °");
  }

  delay(10);
}
*/
void setup() {
  Serial.begin(115200);

  delay(1000);

  if (!imu.begin()) {
    Serial.println("IMU Initialization Failed");
    while (1)
      ;
  }
  // Get one fresh IMU sample
  if (imu.readRawData(data)) {
    imu.convertRawData(data);

    // Do NOT call calibration here for this memory test.
    attitude.initialize(data);
  } else {
    //Serial.println("IMU read failed");
    while (1)
      ;
  }

  previousTime = micros();

  Serial.println("Attitude estimator initialized.");
}
void loop() {
  if (imu.readRawData(data)) {
    unsigned long currentTime = micros();

    float dt =
      (currentTime - previousTime) / 1000000.0f;

    previousTime = currentTime;

    // imu.convertRawData(data);
    imu.applyGyroCalibration(data);
    imu.applyAccelCalibration(data);
    attitude.update(data, dt);

    Serial.print("Roll : ");
    Serial.print(attitude.getRoll(), 2);

    Serial.print(" °   Pitch : ");
    Serial.print(attitude.getPitch(), 2);

    Serial.print(" °   Yaw : ");
    Serial.print(attitude.getYaw(), 2);

    Serial.println(" °");
  }

  delay(100);
}
