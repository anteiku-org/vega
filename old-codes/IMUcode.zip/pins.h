#ifndef PINS_H
#define PINS_H

// ----------------------
// I2C2 Pins
// ----------------------
#define I2C_SDA PB7
#define I2C_SCL PB6

#endif